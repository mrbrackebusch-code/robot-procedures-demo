# Selected corresponding art source

This package includes only the native crops and original source files used by
the image bank. INDEX.json maps exact repository inputs to included copies and
SHA-256 hashes; manifests retain original crop coordinates and modular layers.
Original files retain their original licenses. See docs/ART_CREDITS.md in
the game source or the release ART_CREDITS.md; ../notices contains license texts.

The complete deterministic conversion recipe is tools/build-game-art.py in the
game source. Restore INDEX.json repository paths in an authoring checkout, then
run that script from the repository root. It uses only Pillow and the standard
Python library, not a network service. Its source-specific semantic color ramps,
explicit pivots, fixed cohort scales and generated manifest reproduce the art.
Retain this source, recipe, notices and attribution when redistributing the art.

For the standalone selected-art-source.zip, extract the archive and run its
build-game-art.py with Python/Pillow. It detects the included sources and builds
into rebuilt-game/ without requiring the private authoring checkout or network.
